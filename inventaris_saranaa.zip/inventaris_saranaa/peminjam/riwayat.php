<?php
session_start();
require_once '../config/database.php';
require_once '../config/session.php';
requireRole(['peminjam']);

$db         = new Database();
$conn       = $db->getConnection();
$id_pegawai = $_SESSION['id_pegawai'];

$riwayat = $conn->query(
    "SELECT p.id_peminjaman, p.tanggal_pinjam, p.tanggal_kembali, p.status_peminjaman,
            GROUP_CONCAT(i.nama SEPARATOR ', ') as barang,
            SUM(dp.jumlah) as total_item
     FROM inventaris_sarana_peminjaman p
     JOIN inventaris_sarana_detail_pinjam dp ON p.id_peminjaman = dp.id_peminjaman
     JOIN inventaris_sarana_inventaris i ON dp.id_inventaris = i.id_inventaris
     WHERE p.id_pegawai = $id_pegawai
     GROUP BY p.id_peminjaman ORDER BY p.id_peminjaman DESC"
)->fetchAll();

$pageTitle = 'Riwayat Peminjaman';
include '../includes/header.php';
?>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
  <h3 class="font-semibold text-gray-800 mb-4">Riwayat Peminjaman Saya (<?= count($riwayat) ?>)</h3>
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-xs text-gray-500 border-b border-gray-100">
          <th class="pb-2 font-semibold">No</th>
          <th class="pb-2 font-semibold">Barang</th>
          <th class="pb-2 font-semibold">Jumlah</th>
          <th class="pb-2 font-semibold">Tgl Pinjam</th>
          <th class="pb-2 font-semibold">Tgl Kembali</th>
          <th class="pb-2 font-semibold">Status</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-50">
        <?php if (empty($riwayat)): ?>
        <tr><td colspan="6" class="py-8 text-center text-gray-400">Belum ada riwayat peminjaman</td></tr>
        <?php else: $no=1; foreach ($riwayat as $r): ?>
        <tr class="hover:bg-gray-50">
          <td class="py-3 text-gray-400"><?= $no++ ?></td>
          <td class="py-3 font-medium max-w-[220px]">
            <p class="truncate"><?= htmlspecialchars($r['barang']) ?></p>
          </td>
          <td class="py-3 text-gray-500"><?= $r['total_item'] ?> unit</td>
          <td class="py-3 text-gray-500"><?= formatTanggal($r['tanggal_pinjam']) ?></td>
          <td class="py-3 text-gray-500"><?= $r['tanggal_kembali'] ? formatTanggal($r['tanggal_kembali']) : '-' ?></td>
          <td class="py-3">
            <span class="px-2 py-0.5 rounded-full text-xs font-medium
              <?= $r['status_peminjaman']==='dipinjam' ? 'badge-dipinjam' : 'badge-dikembalikan' ?>">
              <?= ucfirst($r['status_peminjaman']) ?>
            </span>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
