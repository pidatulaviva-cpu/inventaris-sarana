<?php
session_start();
require_once '../config/database.php';
require_once '../config/session.php';
requireRole(['peminjam']);

$db         = new Database();
$conn       = $db->getConnection();
$id_pegawai = $_SESSION['id_pegawai'];

// Cek keterlambatan lebih dari 10 hari
$cekTelat = $conn->prepare(
    "SELECT id_peminjaman, tanggal_kembali,
            DATEDIFF(CURDATE(), tanggal_kembali) AS hari_telat
     FROM inventaris_sarana_peminjaman
     WHERE id_pegawai = :id
       AND status_peminjaman IN ('dipinjam','terlambat')
       AND tanggal_kembali IS NOT NULL
       AND DATEDIFF(CURDATE(), tanggal_kembali) > 10
     ORDER BY hari_telat DESC
     LIMIT 1"
);
$cekTelat->execute([':id' => $id_pegawai]);
$dataTelat = $cekTelat->fetch();
$diblokir  = !empty($dataTelat);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Blokir jika masih ada keterlambatan > 10 hari
    if ($diblokir) {
        flash('error', 'Pengajuan diblokir! Anda memiliki peminjaman terlambat lebih dari 10 hari (ID #' . $dataTelat['id_peminjaman'] . ', telat ' . $dataTelat['hari_telat'] . ' hari). Kembalikan barang terlebih dahulu.');
        redirect(BASE_URL . 'peminjam/peminjaman.php');
    }

    $tgl_pinjam  = $_POST['tanggal_pinjam'];
    $tgl_kembali = $_POST['tanggal_kembali'];
    $items       = $_POST['id_inventaris'] ?? [];
    $jmls        = $_POST['jumlah_pinjam'] ?? [];

    if (empty($items)) {
        flash('error', 'Pilih minimal satu barang.');
        redirect(BASE_URL . 'peminjam/peminjaman.php');
    }

    try {
        $conn->beginTransaction();

        // Validasi server-side: jumlah tidak boleh melebihi stok baik
        foreach ($items as $idx => $id_inv) {
            $jml = max(1, (int)($jmls[$idx] ?? 1));
            $cek = $conn->prepare(
                "SELECT nama, (jumlah - jumlah_rusak) AS stok_bisa_pinjam
                 FROM inventaris_sarana_inventaris WHERE id_inventaris = :id"
            );
            $cek->execute([':id' => (int)$id_inv]);
            $inv = $cek->fetch();
            if ($jml > (int)$inv['stok_bisa_pinjam']) {
                $conn->rollBack();
                flash('error', 'Jumlah pinjam "'.$inv['nama'].'" melebihi stok tersedia ('.$inv['stok_bisa_pinjam'].' unit).');
                redirect(BASE_URL . 'peminjam/peminjaman.php');
            }
        }

        // Status 'menunggu' — menunggu acc operator
        $conn->prepare(
            "INSERT INTO inventaris_sarana_peminjaman
             (tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai)
             VALUES(:tp, :tk, 'menunggu', :ip)"
        )->execute([':tp'=>$tgl_pinjam, ':tk'=>$tgl_kembali, ':ip'=>$id_pegawai]);
        $id_pinjam = $conn->lastInsertId();

        $s = $conn->prepare(
            "INSERT INTO inventaris_sarana_detail_pinjam (id_inventaris, id_peminjaman, jumlah)
             VALUES(:ii, :ip, :j)"
        );
        foreach ($items as $idx => $id_inv) {
            $s->execute([':ii'=>(int)$id_inv, ':ip'=>$id_pinjam, ':j'=>max(1,(int)($jmls[$idx]??1))]);
        }

        $conn->commit();
        flash('success', 'Permintaan peminjaman berhasil diajukan, menunggu persetujuan operator.');
    } catch (Exception $e) {
        $conn->rollBack();
        flash('error', 'Gagal: ' . $e->getMessage());
    }
    redirect(BASE_URL . 'peminjam/peminjaman.php');
}

// Auto-update terlambat
$conn->query(
    "UPDATE inventaris_sarana_peminjaman
     SET status_peminjaman = 'terlambat'
     WHERE status_peminjaman = 'dipinjam'
       AND tanggal_kembali IS NOT NULL
       AND tanggal_kembali < CURDATE()"
);

$inventaris = $conn->query(
    "SELECT id_inventaris, nama, (jumlah - jumlah_rusak) AS stok_bisa_pinjam
     FROM inventaris_sarana_inventaris
     WHERE (jumlah - jumlah_rusak) > 0
     ORDER BY nama"
)->fetchAll();

$mine = $conn->query(
    "SELECT p.*, GROUP_CONCAT(i.nama SEPARATOR ', ') as barang
     FROM inventaris_sarana_peminjaman p
     JOIN inventaris_sarana_detail_pinjam dp ON p.id_peminjaman = dp.id_peminjaman
     JOIN inventaris_sarana_inventaris i ON dp.id_inventaris = i.id_inventaris
     WHERE p.id_pegawai = $id_pegawai
     GROUP BY p.id_peminjaman ORDER BY p.id_peminjaman DESC"
)->fetchAll();

$pageTitle = 'Pinjam Barang';
include '../includes/header.php';
?>

<div class="space-y-6">
  <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
    <h3 class="font-semibold text-gray-800 mb-5">
      <i class="fas fa-hand-holding text-maroon-600 mr-2"></i>Ajukan Peminjaman
    </h3>

    <?php if ($diblokir): ?>
    <div class="bg-red-50 border border-red-300 rounded-xl px-4 py-4 text-sm text-red-700 mb-5">
      <div class="flex items-start gap-3">
        <i class="fas fa-ban text-red-500 text-lg mt-0.5"></i>
        <div>
          <p class="font-semibold text-red-800 mb-1">Pengajuan Peminjaman Diblokir</p>
          <p>Anda memiliki peminjaman <strong>#<?= $dataTelat['id_peminjaman'] ?></strong> yang sudah terlambat
             <strong><?= $dataTelat['hari_telat'] ?> hari</strong> (rencana kembali:
             <strong><?= formatTanggal($dataTelat['tanggal_kembali']) ?></strong>).</p>
          <p class="mt-1">Harap kembalikan barang tersebut terlebih dahulu sebelum mengajukan peminjaman baru.</p>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div class="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 text-sm text-blue-700 mb-5">
      <i class="fas fa-info-circle mr-2"></i>
      Pengajuan akan diproses oleh operator. Stok berkurang setelah disetujui.
    </div>
    <?php endif; ?>
    <form method="POST" class="space-y-5 <?= $diblokir ? 'opacity-40 pointer-events-none select-none' : '' ?>">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="text-sm font-medium text-gray-600 mb-1 block">Tanggal Pinjam *</label>
          <input type="date" name="tanggal_pinjam" value="<?= date('Y-m-d') ?>"
                 class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-maroon-500 outline-none" required>
        </div>
        <div>
          <label class="text-sm font-medium text-gray-600 mb-1 block">Rencana Kembali *</label>
          <input type="date" name="tanggal_kembali"
                 class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-maroon-500 outline-none" required>
        </div>
      </div>

      <div>
        <div class="flex justify-between mb-2">
          <label class="text-sm font-medium text-gray-600">Barang yang Dipinjam *</label>
          <button type="button" onclick="tambahBaris()"
                  class="text-xs bg-maroon-700 text-white px-3 py-1.5 rounded-lg hover:bg-maroon-800">
            <i class="fas fa-plus mr-1"></i>Tambah
          </button>
        </div>
        <div id="barisContainer" class="space-y-2">
          <div class="baris flex gap-2 items-center">
            <select name="id_inventaris[]" onchange="updateMax(this)"
                    class="flex-1 border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-maroon-500 outline-none" required>
              <option value="">-- Pilih Barang --</option>
              <?php foreach ($inventaris as $inv): ?>
              <option value="<?= $inv['id_inventaris'] ?>" data-max="<?= $inv['stok_bisa_pinjam'] ?>">
                <?= htmlspecialchars($inv['nama']) ?>
              </option>
              <?php endforeach; ?>
            </select>
            <input type="number" name="jumlah_pinjam[]" value="1" min="1" max="1"
                   oninput="clampMax(this)"
                   class="w-24 border border-gray-300 rounded-xl px-3 py-2 text-sm text-center focus:ring-2 focus:ring-maroon-500 outline-none">
            <button type="button" onclick="hapusBaris(this)" class="text-red-400 hover:text-red-600 px-2">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
      </div>

      <button type="submit" class="bg-maroon-700 hover:bg-maroon-800 text-white px-6 py-2.5 rounded-xl text-sm font-semibold">
        <i class="fas fa-paper-plane mr-1"></i>Ajukan Peminjaman
      </button>
    </form>
  </div>

  <!-- Riwayat milik pegawai ini -->
  <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
    <h3 class="font-semibold text-gray-800 mb-4">Peminjaman Saya</h3>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-xs text-gray-500 border-b border-gray-100">
            <th class="pb-2">ID</th>
            <th class="pb-2">Barang</th>
            <th class="pb-2">Tgl Pinjam</th>
            <th class="pb-2">Rencana Kembali</th>
            <th class="pb-2">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
          <?php if (empty($mine)): ?>
          <tr><td colspan="5" class="py-6 text-center text-gray-400">Belum ada pengajuan</td></tr>
          <?php else: foreach ($mine as $m):
            $badge = match($m['status_peminjaman']) {
              'menunggu'      => 'bg-blue-100 text-blue-700',
              'dipinjam'      => 'badge-dipinjam',
              'terlambat'     => 'bg-red-100 text-red-700',
              'dikembalikan'  => 'badge-dikembalikan',
              'ditolak'       => 'bg-gray-100 text-gray-500',
              default         => 'bg-gray-100 text-gray-500',
            };
          ?>
          <tr>
            <td class="py-2.5 font-mono text-xs">#<?= $m['id_peminjaman'] ?></td>
            <td class="py-2.5 text-gray-600 max-w-[200px] truncate"><?= htmlspecialchars($m['barang']) ?></td>
            <td class="py-2.5 text-gray-500"><?= formatTanggal($m['tanggal_pinjam']) ?></td>
            <td class="py-2.5 text-gray-500"><?= $m['tanggal_kembali'] ? formatTanggal($m['tanggal_kembali']) : '-' ?></td>
            <td class="py-2.5">
              <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $badge ?>">
                <?= ucfirst($m['status_peminjaman']) ?>
              </span>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
// Data stok dari PHP — key: id_inventaris, value: stok_bisa_pinjam
const stokData = {
  <?php foreach ($inventaris as $inv): ?>
  <?= $inv['id_inventaris'] ?>: <?= $inv['stok_bisa_pinjam'] ?>,
  <?php endforeach; ?>
};

// Saat barang dipilih, update max input jumlah dan reset ke 1
function updateMax(sel) {
  const id  = parseInt(sel.value);
  const max = stokData[id] || 1;
  const input = sel.closest('.baris').querySelector('input[type=number]');
  input.max   = max;
  input.value = 1;
}

// Paksa nilai tidak melebihi max saat diketik manual
function clampMax(input) {
  const max = parseInt(input.max) || 1;
  const min = parseInt(input.min) || 1;
  if (parseInt(input.value) > max) input.value = max;
  if (parseInt(input.value) < min) input.value = min;
}

// Template option untuk baris baru
const invOpts = `<?php foreach($inventaris as $inv): ?><option value="<?= $inv['id_inventaris'] ?>" data-max="<?= $inv['stok_bisa_pinjam'] ?>"><?= htmlspecialchars($inv['nama']) ?></option><?php endforeach; ?>`;

function tambahBaris() {
  const c = document.getElementById('barisContainer');
  const d = document.createElement('div');
  d.className = 'baris flex gap-2 items-center';
  d.innerHTML = `
    <select name="id_inventaris[]" onchange="updateMax(this)"
            class="flex-1 border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-maroon-500 outline-none" required>
      <option value="">-- Pilih Barang --</option>${invOpts}
    </select>
    <input type="number" name="jumlah_pinjam[]" value="1" min="1" max="1"
           oninput="clampMax(this)"
           class="w-24 border border-gray-300 rounded-xl px-3 py-2 text-sm text-center focus:ring-2 focus:ring-maroon-500 outline-none">
    <button type="button" onclick="hapusBaris(this)" class="text-red-400 hover:text-red-600 px-2">
      <i class="fas fa-times"></i>
    </button>`;
  c.appendChild(d);
}

function hapusBaris(btn) {
  if (document.querySelectorAll('.baris').length > 1) btn.closest('.baris').remove();
}
</script>

<?php include '../includes/footer.php'; ?>