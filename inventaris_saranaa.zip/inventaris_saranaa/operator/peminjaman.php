<?php
session_start();
require_once '../config/database.php';
require_once '../config/session.php';
requireRole(['operator']);

$db   = new Database();
$conn = $db->getConnection();

// Auto-update terlambat
$conn->query(
    "UPDATE inventaris_sarana_peminjaman
     SET status_peminjaman = 'terlambat'
     WHERE status_peminjaman = 'dipinjam'
       AND tanggal_kembali IS NOT NULL
       AND tanggal_kembali < CURDATE()"
);

/* ── ACC (setujui) peminjaman ── */
if (isset($_GET['acc'])) {
    $id = (int)$_GET['acc'];

    // Cek apakah peminjam sedang diblokir (keterlambatan > 10 hari)
    $cekBlokir = $conn->prepare(
        "SELECT p2.id_peminjaman, DATEDIFF(CURDATE(), p2.tanggal_kembali) AS hari_telat
         FROM inventaris_sarana_peminjaman p1
         JOIN inventaris_sarana_peminjaman p2 ON p2.id_pegawai = p1.id_pegawai
         WHERE p1.id_peminjaman = :id
           AND p2.status_peminjaman IN ('dipinjam','terlambat')
           AND p2.tanggal_kembali IS NOT NULL
           AND DATEDIFF(CURDATE(), p2.tanggal_kembali) > 10
         ORDER BY hari_telat DESC
         LIMIT 1"
    );
    $cekBlokir->execute([':id' => $id]);
    $blokir = $cekBlokir->fetch();
    if ($blokir) {
        flash('error', 'Peminjaman tidak dapat disetujui. Peminjam memiliki keterlambatan ' . $blokir['hari_telat'] . ' hari pada peminjaman #' . $blokir['id_peminjaman'] . '. Minta peminjam mengembalikan barang terlebih dahulu.');
        redirect('peminjaman.php');
    }

    try {
        $conn->beginTransaction();

        // Ambil detail barang
        $detail = $conn->prepare(
            "SELECT id_inventaris, jumlah FROM inventaris_sarana_detail_pinjam WHERE id_peminjaman = :id"
        );
        $detail->execute([':id' => $id]);
        $rows = $detail->fetchAll();

        foreach ($rows as $row) {
            // Cek stok & kondisi barang
            $stok = $conn->prepare(
                "SELECT nama, jumlah, jumlah_rusak,
                        (jumlah - jumlah_rusak) AS stok_bisa_pinjam
                 FROM inventaris_sarana_inventaris
                 WHERE id_inventaris = :id"
            );
            $stok->execute([':id' => $row['id_inventaris']]);
            $inv = $stok->fetch();

            // Blokir jika Rusak Berat (semua unit rusak)
            if ($inv['jumlah_rusak'] >= $inv['jumlah']) {
                $conn->rollBack();
                flash('error', '"'.$inv['nama'].'" kondisi Rusak Berat, tidak dapat dipinjam!');
                redirect('peminjaman.php');
            }

            // Blokir jika stok baik tidak mencukupi
            if ((int)$inv['stok_bisa_pinjam'] < (int)$row['jumlah']) {
                $conn->rollBack();
                flash('error', 'Stok baik "'.$inv['nama'].'" tidak mencukupi. Tersedia: '.$inv['stok_bisa_pinjam'].' unit.');
                redirect('peminjaman.php');
            }

            // Kurangi stok total — gunakan parameter berbeda agar tidak HY093
            $conn->prepare(
                "UPDATE inventaris_sarana_inventaris
                 SET jumlah = jumlah - :kurang
                 WHERE id_inventaris = :inv_id"
            )->execute([':kurang' => $row['jumlah'], ':inv_id' => $row['id_inventaris']]);
        }

        // Update status ke dipinjam
        $conn->prepare(
            "UPDATE inventaris_sarana_peminjaman
             SET status_peminjaman = 'dipinjam'
             WHERE id_peminjaman = :pid"
        )->execute([':pid' => $id]);

        $conn->commit();
        flash('success', 'Peminjaman #'.$id.' berhasil disetujui.');

    } catch (Exception $e) {
        $conn->rollBack();
        flash('error', 'Gagal: ' . $e->getMessage());
    }
    redirect('peminjaman.php');
}

/* ── TOLAK peminjaman ── */
if (isset($_GET['tolak'])) {
    $id = (int)$_GET['tolak'];
    $conn->prepare(
        "UPDATE inventaris_sarana_peminjaman SET status_peminjaman = 'ditolak' WHERE id_peminjaman = :id"
    )->execute([':id' => $id]);
    flash('success', 'Peminjaman #'.$id.' ditolak.');
    redirect('peminjaman.php');
}

// Menunggu acc — dengan info blokir
$menunggu = $conn->query(
    "SELECT p.*, pg.nama_pegawai,
            GROUP_CONCAT(i.nama, ' (', dp.jumlah, ')' SEPARATOR ', ') as barang,
            SUM(dp.jumlah) as total_item,
            (SELECT MAX(DATEDIFF(CURDATE(), p2.tanggal_kembali))
             FROM inventaris_sarana_peminjaman p2
             WHERE p2.id_pegawai = p.id_pegawai
               AND p2.status_peminjaman IN ('dipinjam','terlambat')
               AND p2.tanggal_kembali IS NOT NULL
               AND DATEDIFF(CURDATE(), p2.tanggal_kembali) > 10
            ) AS hari_telat_blokir
     FROM inventaris_sarana_peminjaman p
     JOIN inventaris_sarana_pegawai pg ON p.id_pegawai = pg.id_pegawai
     JOIN inventaris_sarana_detail_pinjam dp ON p.id_peminjaman = dp.id_peminjaman
     JOIN inventaris_sarana_inventaris i ON dp.id_inventaris = i.id_inventaris
     WHERE p.status_peminjaman = 'menunggu'
     GROUP BY p.id_peminjaman
     ORDER BY p.tanggal_pinjam ASC"
)->fetchAll();

// Semua riwayat
$semua = $conn->query(
    "SELECT p.*, pg.nama_pegawai,
            GROUP_CONCAT(i.nama SEPARATOR ', ') as barang,
            SUM(dp.jumlah) as total_item
     FROM inventaris_sarana_peminjaman p
     JOIN inventaris_sarana_pegawai pg ON p.id_pegawai = pg.id_pegawai
     JOIN inventaris_sarana_detail_pinjam dp ON p.id_peminjaman = dp.id_peminjaman
     JOIN inventaris_sarana_inventaris i ON dp.id_inventaris = i.id_inventaris
     WHERE p.status_peminjaman != 'menunggu'
     GROUP BY p.id_peminjaman
     ORDER BY p.id_peminjaman DESC LIMIT 30"
)->fetchAll();

$pageTitle = 'ACC Peminjaman';
include '../includes/header.php';
?>

<div class="space-y-6">

  <!-- Menunggu ACC -->
  <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
    <div class="flex items-center gap-2 mb-4">
      <h3 class="font-semibold text-gray-800">Menunggu Persetujuan</h3>
      <?php if (count($menunggu) > 0): ?>
      <span class="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-0.5 rounded-full animate-pulse">
        <?= count($menunggu) ?> baru
      </span>
      <?php endif; ?>
    </div>

    <?php if (empty($menunggu)): ?>
    <div class="text-center py-8 text-gray-400">
      <i class="fas fa-inbox text-3xl mb-2 block"></i>
      Tidak ada permintaan peminjaman baru
    </div>
    <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($menunggu as $m): $isBlokir = !empty($m['hari_telat_blokir']); ?>
      <div class="border <?= $isBlokir ? 'border-red-300 bg-red-50' : 'border-blue-200 bg-blue-50' ?> rounded-xl p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div class="flex-1">
            <div class="flex items-center gap-2 mb-1">
              <p class="font-semibold text-gray-800"><?= htmlspecialchars($m['nama_pegawai']) ?></p>
              <span class="text-xs bg-blue-200 text-blue-800 px-2 py-0.5 rounded-full">Menunggu</span>
              <?php if ($isBlokir): ?>
              <span class="text-xs bg-red-200 text-red-800 px-2 py-0.5 rounded-full font-semibold">
                <i class="fas fa-ban mr-1"></i>Diblokir – telat <?= $m['hari_telat_blokir'] ?> hari
              </span>
              <?php endif; ?>
            </div>
            <?php if ($isBlokir): ?>
            <p class="text-xs text-red-600 mb-1 font-medium">
              <i class="fas fa-exclamation-triangle mr-1"></i>
              Peminjam memiliki barang yang terlambat dikembalikan lebih dari 10 hari. Tidak dapat disetujui.
            </p>
            <?php endif; ?>
            <p class="text-sm text-gray-600 mb-1">
              <i class="fas fa-boxes-stacked text-gray-400 mr-1"></i>
              <?= htmlspecialchars($m['barang']) ?>
            </p>
            <div class="flex gap-4 text-xs text-gray-500">
              <span><i class="fas fa-calendar-plus mr-1"></i>Pinjam: <?= formatTanggal($m['tanggal_pinjam']) ?></span>
              <span><i class="fas fa-calendar-check mr-1"></i>Kembali: <?= $m['tanggal_kembali'] ? formatTanggal($m['tanggal_kembali']) : '-' ?></span>
              <span><i class="fas fa-hashtag mr-1"></i><?= $m['total_item'] ?> item</span>
            </div>
          </div>
          <div class="flex gap-2 flex-shrink-0">
            <?php if ($isBlokir): ?>
            <span class="flex items-center gap-1.5 bg-gray-300 text-gray-500 px-4 py-2 rounded-xl text-xs font-semibold cursor-not-allowed" title="Peminjam diblokir karena keterlambatan">
              <i class="fas fa-ban"></i> Diblokir
            </span>
            <?php else: ?>
            <a href="?acc=<?= $m['id_peminjaman'] ?>"
               onclick="return confirm('Setujui peminjaman dari <?= htmlspecialchars($m['nama_pegawai']) ?>?')"
               class="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl text-xs font-semibold">
              <i class="fas fa-circle-check"></i> ACC
            </a>
            <?php endif; ?>
            <a href="?tolak=<?= $m['id_peminjaman'] ?>"
               onclick="return confirm('Tolak peminjaman ini?')"
               class="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-semibold">
              <i class="fas fa-circle-xmark"></i> Tolak
            </a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Riwayat -->
  <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
    <h3 class="font-semibold text-gray-800 mb-4">Riwayat Peminjaman</h3>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-xs text-gray-500 border-b border-gray-100">
            <th class="pb-2 font-semibold">ID</th>
            <th class="pb-2 font-semibold">Pegawai</th>
            <th class="pb-2 font-semibold">Barang</th>
            <th class="pb-2 font-semibold">Tgl Pinjam</th>
            <th class="pb-2 font-semibold">Rencana Kembali</th>
            <th class="pb-2 font-semibold">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
          <?php if (empty($semua)): ?>
          <tr><td colspan="6" class="py-6 text-center text-gray-400">Belum ada data</td></tr>
          <?php else: foreach ($semua as $d):
            $badge = match($d['status_peminjaman']) {
              'dipinjam'     => 'badge-dipinjam',
              'terlambat'    => 'bg-red-100 text-red-700',
              'dikembalikan' => 'badge-dikembalikan',
              'ditolak'      => 'bg-gray-100 text-gray-500',
              default        => 'bg-gray-100 text-gray-500',
            };
          ?>
          <tr class="hover:bg-gray-50">
            <td class="py-2.5 font-mono text-xs">#<?= $d['id_peminjaman'] ?></td>
            <td class="py-2.5 font-medium"><?= htmlspecialchars($d['nama_pegawai']) ?></td>
            <td class="py-2.5 text-gray-500 max-w-[200px] truncate"><?= htmlspecialchars($d['barang']) ?></td>
            <td class="py-2.5 text-gray-500"><?= formatTanggal($d['tanggal_pinjam']) ?></td>
            <td class="py-2.5 text-gray-500"><?= $d['tanggal_kembali'] ? formatTanggal($d['tanggal_kembali']) : '-' ?></td>
            <td class="py-2.5">
              <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $badge ?>">
                <?= ucfirst($d['status_peminjaman']) ?>
              </span>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>